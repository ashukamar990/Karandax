
(async () => {

    window.shiprocketSmartCartLoaded = false;

    const container = document.querySelector('[data-app="shiprocket-smart-cart"]'); 
    const shadowRoot = container.shadowRoot || container.attachShadow({ mode: 'open' });

    document.addEventListener('DOMContentLoaded', () => {
      if (!container) return;
    
      // Inject external CSS into shadow
      const cssUrl = window.shiprocketSmartCart?.cssUrl;
      if (cssUrl) {
        fetch(cssUrl)
          .then(res => res.text())
          .then(css => {
            const style = document.createElement('style');
            style.textContent = css;
            shadowRoot.appendChild(style);
            window.shiprocketSmartCartLoaded = true;
          })
          .catch((err) => {
            console.warn('Failed to load Smart Cart CSS', err)
          });
      }
    
      // Inject HTML from <template>
      const template = document.getElementById('shiprocket-smart-cart-html-template');
      if (template) {
        const clone = template.content.cloneNode(true);
        shadowRoot.appendChild(clone);
        template.remove(); // Clean up after injecting
      }
    });

    // mini cart update function
    window.uniqueCartId = new Date(); 

    const removeExistingCartHTML = () => {
      try {
        document.getElementsByTagName('cart-drawer')?.[0]?.remove();
        document.getElementById('halo-cart-sidebar')?.remove()
      } catch (e) {}
    }
  
    document.addEventListener('DOMContentLoaded', () => {
      removeExistingCartHTML()
      // selectors
      const cartItemLoader = shadowRoot.querySelector('.cart-items-loader');
      const MINI_CART_CONTAINER  = shadowRoot.getElementById("shiprocket-mini-cart-container");
      const MINI_CART_ITEMS_CONTAINER = shadowRoot.getElementById('mini-cart-items');
      const MINI_CART_TOTAL_ITEMS = shadowRoot.querySelector('.item_count');
      const CART_SUMMARY_TOTAL = shadowRoot.querySelector(".total-price");
      const CART_SUMMARY_SUB_TOTAL = shadowRoot.querySelector(".sr-sub-total");
  
  
    
      /*---------------- uitls functions --------------------*/
      // show drawer function 
      window.srHideMiniCartDrawer = () => {
        shadowRoot.querySelector('.mini-cart-empty-cart-container').style.display = "flex";
        shadowRoot.querySelector('.mini-cart-body').style.display = "none";
        shadowRoot.querySelector('.mini-cart-order-summary').style.display = "none";
        shadowRoot.querySelector('.mini-cart-footer').style.display = "none";
      }
  
      window.srShowMiniCartDrawer = () => {
        shadowRoot.querySelector('.mini-cart-body').style.display = "block";
        shadowRoot.querySelector('.mini-cart-order-summary').style.display = "block";
        shadowRoot.querySelector('.mini-cart-footer').style.display = "block";
        shadowRoot.querySelector('.mini-cart-empty-cart-container').style.display = "none";
      }
  
      function updateCartSummaryThroughShopifyData(cartData){
        MINI_CART_TOTAL_ITEMS.textContent = cartData?.items?.length;
        CART_SUMMARY_TOTAL.innerHTML = `₹${(cartData?.items_subtotal_price / 100)?.toFixed(2) ?? 0}`
        CART_SUMMARY_SUB_TOTAL.innerHTML = `₹${(cartData?.total_price / 100)?.toFixed(2) ?? 0}`;
      }
  
      const slideMiniCartInFrame = () => {
        
        //main shadowRoot wrapper container
        container.style.display = "block";
        
        history?.pushState({ srSmartCartOpen: true }, '', '');
        MINI_CART_CONTAINER.style.display = 'block';
        hideLoader()
        hideShiprocketSmartCartDrawers();
        document.body.classList.add('srsc-overflow-hidden');
      }
  
      /*---------------- end uitls functions --------------------*/

      {/** SELLER BASED HANDLERS */}

      const swashaaGiftWrapHandler = async () => { 
        try {
          const giftWrapCheckbox = document.getElementById('ptw-gift-needed').checked;
          const giftWrapNote = document.getElementById('ptw-text-message').value;
          const productName = document.getElementById("ptw-wrapin").getAttribute("data-productname");
          if(giftWrapCheckbox) {
            await addToCart({
              productData: {
                id: 47312311156960,
                quantity: 1,
                properties: {
                  'Gift Wrap': 'Yes',
                  'Gift Note': giftWrapNote,
                  'Product': productName
                }
              },
              throwError: false
            })
          }
          return
        } catch (e) { return }
      }
  
  
  
     /* ---------------- responsible for udpating cart Items --------------- */
      const addToCart = async (data) => {
        try {
          let response = await fetch('/cart/add.js', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data?.productData)
          })
          if(!response.ok) {
            return
          }
          response = await response.json();
          return response
        } catch (e) { 
          if(data.throwError) {}
          return 
        }
      }

      window.updateMiniCartSection = async function (data = {}) {
        try {
          showLoader()
          //const response = await fetch('/?section_id=smart-cart');
          let currentCartData = {};

          if(!data.updatedCart) {
            const currentCart = await fetch('/cart.js?srsc=1');
            currentCartData = await currentCart.json();
          } else {
            currentCartData = data?.updatedCart
          }

          if (currentCartData) {
            //show empty screen if there are no items 
            !(currentCartData?.items?.length > 0) 
            ? srHideMiniCartDrawer() 
            : srShowMiniCartDrawer()
            
  
            if (currentCartData) {
              try {
                const cartSummaryObjectShopifyInCaseOfApiFail = {
                   total:  (currentCartData?.items_subtotal_price / 100) ?? 0, 
                   subTotal: (currentCartData?.total_price / 100) ?? 0,
                   discountDescription: null
                }
                
               await window.miniCartInit(currentCartData?.items, false, uniqueCartId, cartSummaryObjectShopifyInCaseOfApiFail);
              } catch (error) {
                updateCartSummaryThroughShopifyData(currentCartData)
                // shadowRoot.querySelector('.mini-card-sr-loader').setAttribute("style", "display: none !important;");
                // cartItemLoader.setAttribute("style", "display: none !important");
              }
            }
          } else {
            // shadowRoot.querySelector('.mini-card-sr-loader').setAttribute("style", "display: none !important;");
            // cartItemLoader.setAttribute("style", "display: none !important")
          }
  
          let cartItemsHTML = currentCartData?.items?.map((item) => {
            const itemCacheData = window.shiprocketCartPriceCache?.[item.id] ?? {};
            return `
              <div class="mini-cart-item">
                <div style="display: flex; width: 100%">
                  <div class="sr-cart-item-image-container">
                    <img
                      src="${item.image}"
                      alt="${item.title}"
                      loading="lazy"
                      class="sr-cart-item-image"
                    />
                  </div>
                  <div class="mini-cart-item-details">
                    <div class="mini-cart-item-title">
                      <a class="mini-cart-item-title-content" href="${item.url}">
                        ${item.product_title}
                      </a>
                    </div>
                    <div style="display: flex; justify-content: space-between; width: 100%">
                    <div>
                    <div class="mini-cart-item-variant">
                      ${item?.variant_title ?? ""}
                    </div>
                    <div class="mini-cart-item-price">
                      ₹${((item.price)/100)?.toFixed(2)}
                      <div class="sr-compare-at-price-container" id="sr-cart-item-${item.id}">`
                      +
                      (
                        itemCacheData?.compare_at_price > itemCacheData?.price ?
                        `<div class="sr-cart-cut-out-price">₹${(itemCacheData?.compare_at_price / 100)?.toFixed(0)}</div>
                        <div class="sr-cart-percent-discount-text">${itemCacheData?.percent_diff}% off</div>` : 
                        ""
                      )
                      +
                      `</div>
                    </div>
                    </div>
                    <div class="min-cart-item-controll-wrapper">
                    <div class="mini-cart-item-container">
                      <button
                        class="mini-cart-item-delete"
                        data-quantity="${item.quantity - 1}"
                        data-id="${item.key}"
                        onclick="deleteMiniCartItemHandler(event)"
                      >
                        <svg xmlns="http://www.w3.org/2000/svg" width="10" height="18" viewBox="0 0 8 11" fill="none">
                          <path d="M0.571429 9.41025C0.571429 10.0308 1.08571 10.5385 1.71429 10.5385H6.28571C6.91429 10.5385 7.42857 10.0308 7.42857 9.41025V2.64102H0.571429V9.41025ZM1.71429 3.76923H6.28571V9.41025H1.71429V3.76923ZM6 0.948716L5.42857 0.384613H2.57143L2 0.948716H0V2.07692H8V0.948716H6Z" fill="#666666" />
                        </svg>
                      </button>
                      <div class="mini-cart-item-actions">
                        <button
                          class="mini-cart-qty-btn"
                          name="quantity"
                          data-quantity="${item.quantity - 1}"
                          data-id="${item.key}"
                          style="cursor: pointer"
                          onclick="handleItemQuantityUpdate(${item.id}, ${item.quantity - 1})"
                        >
                          -
                        </button>
                        <input readonly type="text" value="${item.quantity}" class="mini-cart-item-qty" data-id="${item.key}" />
                        <button
                          class="mini-cart-qty-btn"
                          name="quantity"
                          data-quantity="${item.quantity + 1}"
                          data-id="${item.key}"
                          style="cursor: pointer"
                          onclick="handleItemQuantityUpdate(${item.id}, ${item.quantity + 1})"
                        >
                          +
                        </button>
                        <div class="mini-cart-qty-loader"></div>
                      </div>
                    </div>
                  </div>
                    </div>
                  </div>
                </div>
              </div>
            `;
          }).join("");
        
          MINI_CART_ITEMS_CONTAINER.innerHTML = cartItemsHTML;

          hideLoader()
          
        } catch (error) {
          hideLoader()
          // cartItemLoader.setAttribute("style", "display: none !important")
          // shadowRoot.querySelector('.mini-card-sr-loader').setAttribute("style", "display: none !important;");
          console.error('Error updating mini-cart section:', error);
        }
  
        
  
        
      };
  
  
      // Reinitialize event listeners for mini-cart
      function reinitializeMiniCartListeners() {
        // Add event listeners for quantity buttons
        shadowRoot.querySelectorAll('.mini-cart-qty-btn').forEach(button => {
          button.addEventListener('click', handleQtyButtonClick);
        });
  
        shadowRoot.querySelectorAll('.mini-cart-item-qty').forEach(button => {
          button.addEventListener('change', handleQtyButtonClickInput);
        });        
      }
  
      
      function qtyButtonLoader(state, loader) {
        shadowRoot.querySelectorAll('.mini-cart-qty-loader').forEach((btn) => {
          btn.setAttribute("style", `display: ${loader} !important;`);
        })
  
        shadowRoot.querySelectorAll('.mini-cart-item-qty').forEach((btn) => {
          btn.style.display = state;
        })
  
        shadowRoot.querySelectorAll('.mini-cart-qty-btn').forEach((btn) => {
          btn.style.display = state;
        })
      }
  
  
      async function handleQtyButtonClickInput(e) {
          e.preventDefault();
          const button = e.currentTarget;
          const allDeleteButton = shadowRoot.querySelectorAll('.mini-cart-item-delete')
          const itemId = this.getAttribute('data-id');
          const newQuantity = e.target.value;
  
          if(newQuantity > 0){
            try {
              showLoader()
              if (allDeleteButton) {
                allDeleteButton.forEach((button) => {
                  button.style.opacity = '.5';
                  button.disabled = true;
                })
          }
        const response = await fetch('/cart/change.js', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ id: itemId, quantity: newQuantity }),
        });
  
        if (response.ok) {
          updateMiniCartSection(); // Refresh the mini-cart
        } else {
          hideLoader()
          alert('Failed to update quantity. Please try again')
          console.error('Failed to update quantity.');
        }
        hideLoader()
        if (allDeleteButton) {
          allDeleteButton.forEach((button) => {
            button.style.opacity = '1';
            button.disabled = false;
          })
        }
      } catch (error) {
        if (allDeleteButton) {
          allDeleteButton.forEach((button) => {
            button.style.opacity = '1';
            button.disabled = false;
          })
        }
        hideLoader()
        console.error('Error updating cart:', error);
      }
    }
  }
  
  
      
      // Handle quantity button clicks
      async function handleQtyButtonClick(e) {
        e.preventDefault();
  
        const button = e.currentTarget;
        const miniCartItem = button.closest('.mini-cart-item');
        // const deleteButton = miniCartItem.querySelector('.mini-cart-item-delete');
        const allDeleteButton = shadowRoot.querySelectorAll('.mini-cart-item-delete')
  
        
        const itemId = this.getAttribute('data-id');
        const newQuantity = this.getAttribute('data-quantity');
  
        try {
          showLoader()
          if (allDeleteButton) {
            allDeleteButton.forEach((button) => {
              button.style.opacity = '.5';
              button.disabled = true;
            })
          }
  
          // deleteButton.style.opacity = '.5';
          // deleteButton.disabled = true;
          let response = await fetch('/cart/change.js', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id: itemId, quantity: newQuantity }),
          });

          if(!response.ok) {
            throw new Error('Failed to update quanity');
          }
  
          response = await response.json();
          
          updateMiniCartSection({
            updatedCart: response
          });

          
          // qtyButtonLoader("block", "none");
          // if (allDeleteButton) {
          //   allDeleteButton.forEach((button) => {
          //     button.style.opacity = '1';
          //     button.disabled = false;
          //   })
          // }
  
          // deleteButton.style.opacity = '1';
          // deleteButton.disabled = false;
        } catch (error) {
          hideLoader()
          showSRSCToast(`Oops! Failed to update cart.`)

          if (allDeleteButton) {
            allDeleteButton.forEach((button) => {
              button.style.opacity = '1';
              button.disabled = false;
            })
          }
  
          // deleteButton.style.opacity = '1';
          // deleteButton.disabled = false;
        }
      }
  
      document.querySelectorAll('a[href="/cart"]').forEach(button => {
          button.addEventListener('click', async function (event) {
            if(!window.shiprocketSmartCartLoaded) {
              return
            }
              event.preventDefault();
              event.stopPropagation();
               if (MINI_CART_CONTAINER) {
                    slideMiniCartInFrame();
                    if(window.refetchSRSCOnOpen) {
                      updateMiniCartSection();
                    }
                }
                    setTimeout(() => {
                      shadowRoot.querySelector('.mini-cart-drawer').style.transform = "translateX(0)";
                }, 100)
          }); 
      }, true);

      // Handle Add to Cart button
      document.addEventListener('click', async function (event) {

        if(!window.shiprocketSmartCartLoaded) {
          return
        }

        let variantId = null;
        let quantity = 1;
        let button = null;
      
        // Check for form-based button
        button = event.target.closest('form[action^="/cart/add"] [type="submit"]') ?? event.target.closest('form[action^="/cart/add"] [name="add"]');
        if (button) {
          event.preventDefault();
          event.stopPropagation();
      
          const form = button.closest('form');
          if (!form) {
            return console.error('Add to Cart button not inside a form.');
          }
      
          const formData = new FormData(form);
          variantId = formData.get('id');
          quantity = parseInt(formData.get('quantity')) || 1;
      
          if (!variantId) {
            console.error('Variant ID not found in form.');
            return;
          }
        }
      
        // Else check for data-variant-id button
        else {

          const btnTextMatchArray = ['add to cart', 'quick buy']; // Add more strings here as needed

          button = event.target.closest('[data-variant-id]');
          if (!button) {
            return;
          }
        
          const buttonText = button?.textContent?.trim()?.toLowerCase();
          const buttonTitle = button?.getAttribute("title")?.trim()?.toLowerCase();
        
          // Check if the text matches any of the allowed values
          const btnTextMatched = btnTextMatchArray?.some(text => (buttonText === text || buttonTitle === text ));
          if (!btnTextMatched) {
            return;
          }

          event.preventDefault();
          event.stopPropagation();
      
          variantId = button.getAttribute('data-variant-id');
          if (!variantId) {
            console.error('Variant ID not found on button.');
            return;
          }
      
          const quantityInput = button.closest('[data-current-qty]') ||
                                button.parentElement?.querySelector('[data-current-qty]') ||
                                document.querySelector('[data-current-qty]');
      
          quantity = parseInt(quantityInput?.value) || 1;
        }
      
        //disable button and other handling
        button.disabled = true;
        window.srShowConfetti = true;
        const uniqueCartId = Date.now();
        showLoader();
        try {

          //custom handling for swashaa gift wrap 
          if(window.location.hostname === 'www.swashaa.com') {
            await swashaaGiftWrapHandler()
          }

          const response = await fetch('/cart/add.js', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id: variantId, quantity }),
          });
      
          if (!response.ok) {
            throw new Error(`Server responded with ${response.status}`);
          }
      
          const cartItem = await response.json();
          console.log('Added to cart:', cartItem);
      
          //Smart Cart in View
          slideMiniCartInFrame();
          setTimeout(() => {
            shadowRoot.querySelector('.mini-cart-drawer')?.style?.setProperty('transform', 'translateX(0)');
          }, 100);
      
          await updateMiniCartSection();
          button.disabled = false;
      
        } catch (error) {
          button.disabled = false;
          hideLoader();
          alert('Failed to add item to cart.');
          console.error('Error adding item to cart:', error);
        }
      }, true);

    
      reinitializeMiniCartListeners();
    });
  
    
    window.handleItemQuantityUpdate = async (variantId, quantity) => {
      try {
        showLoader()
        let response = await fetch("/cart/change.js", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ id: String(variantId), quantity: quantity })
        });

        if(!response.ok) {
          throw new Error('Failed to update quanity');
        }

        response = await response.json();
        
        updateMiniCartSection({
          updatedCart: response
        });
      } catch (e) {
        hideLoader();
        showSRSCToast(`Oops! Failed to update cart.`)
      }
    }

    const deleteMiniCartItemHandler = async (event) => {
  
      const button = event.currentTarget;
      const itemId = button.getAttribute('data-id');
      const miniCartItem = button.closest('.mini-cart-item');
  
      if (miniCartItem) {
        miniCartItem.style.opacity = '0.5';
        miniCartItem.style.transition = 'opacity 0.3s ease-in-out';
  
        const allButtons = miniCartItem.querySelectorAll('button');
  
        allButtons.forEach(btn => {
          btn.disabled = true;
          btn.style.opacity = '0.5';
          btn.style.cursor = 'not-allowed';
        });
      }
  
      try {
        const response = await fetch("/cart/change.js", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ id: itemId, quantity: 0 })
        });
  
        const data = await response.json();
  
        //  have to add animations here
        // if (miniCartItem) {
          // miniCartItem.classList.add('minimize-animation');
          // setTimeout(() => {
            // miniCartItem.remove();
            updateMiniCartSection();
          // }, 300);
        // } else {
        //   updateMiniCartSection();
        // }
      } catch (error) {
  
        const allButtons = miniCartItem.querySelectorAll('button');
  
        if (miniCartItem) {
          miniCartItem.style.opacity = '1';
          miniCartItem.style.transition = 'opacity 0.3s ease-in-out';
  
          allButtons.forEach(btn => {
            btn.disabled = false;
            btn.style.opacity = '1';
            btn.style.cursor = 'pointer';
          });
        }
        console.error("Error removing item:", error);
        alert("An error occurred while removing the item. Please try again.");
      }
    };

    const handleHistoryForBrowserBackButton = () => {
      try {
        //can add a check for manual close button click as well - this handles browser back button clicks
        if (history.state?.srSmartCartOpen) {
          history.back();
        }
      } catch (e) {}
    }
    
    window.closeMiniCartDrawerHandler = (event, browserBackButtonClicked = false) => {
      try {
        event.preventDefault();

        if(!browserBackButtonClicked) {
          handleHistoryForBrowserBackButton();
        }
        
        const miniCartDrawer = shadowRoot.querySelector('.mini-cart-drawer');
        const parentAddToCartButtons = document.querySelectorAll('form[action^="/cart/add"] [type="submit"]');
        
        miniCartDrawer.style.transform = "translateX(100%)";
        parentAddToCartButtons.forEach(button => button.disabled = false);  // we can remove this condition after code review
        document.body.classList.remove('srsc-overflow-hidden');
        document.body.classList.remove("overflow-hidden");
        document.body.classList.remove("cart-sidebar-show");

        setTimeout(() => {
          shadowRoot.getElementById("shiprocket-mini-cart-container").style.display = 'none';
        }, 300)
  
        uniqueCartId = "";
        showLoader()
        
        if(!window.srcSuggestedItemsExist && window.loadSimilarItems) {
          window.loadSimilarItems([]); // empty similar item
        }
        if(window.srShowConfetti) window.srShowConfetti = false;


      } catch(error){
        document.body.classList.remove('srsc-overflow-hidden');
      }
    }

    //handling browser back button click
    window.addEventListener('popstate', (event) => {
      if (!event.state || !event.state.srSmartCartOpen) {
        closeMiniCartDrawerHandler(event, true);
      }
    });

    document.addEventListener('DOMContentLoaded', async function () {
      try {
        let cartItems = window?.shiprocketSmartCart?.currentCart?.items
        if(!cartItems) {
          const currentCart = await fetch('/cart.js?srsc=1');
          const currentCartData = await currentCart.json();
          cartItems = currentCartData?.items
        }
        if(window.miniCartInit) {
          window.miniCartInit(cartItems, true, uniqueCartId);
        }
        if(cartItems?.length === 0) {
          window.srHideMiniCartDrawer();
        }
      } catch (error) {
        window.miniCartInit([], true, uniqueCartId);
        window.srHideMiniCartDrawer();
        console.log('SRSC: Initial Init Failed:', error)
      }
    })
  
})()